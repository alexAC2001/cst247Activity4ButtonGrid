﻿using ButtonGrid.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ButtonGrid.Controllers
{
    public class ButtonController : Controller
    {
        // create a list of buttons
        static List<ButtonModel> buttons = new List<ButtonModel>();
        Random random = new Random();
        const int GRID_SIZE = 25;

        public IActionResult Index()
        {
            // empty the list when the page loads
            buttons = new List<ButtonModel>();

            // Generate some new buttons. Randomly chosen color values
            for(int i = 0; i < GRID_SIZE; i++)
            {
                buttons.Add(new ButtonModel(i, random.Next(4)));
            }
            /*// when the page loads, generate some new buttons. Randomly chosen values
            buttons.Add(new ButtonModel(0, 0));
            buttons.Add(new ButtonModel(1, 3));
            buttons.Add(new ButtonModel(2, 0));
            buttons.Add(new ButtonModel(3, 1));
            buttons.Add(new ButtonModel(4, 2));
            */
            // send the button list to the "Index" page
            return View("Index", buttons);
        }

        public IActionResult HandleButtonClick(string buttonNumber)
        {
            // convert from string to int
            int bN = int.Parse(buttonNumber);
            // add one to the button state. If greater than 4, reset to 0
            buttons.ElementAt(bN).ButtonState = ( buttons.ElementAt(bN).ButtonState + 1 ) % 4;

           /* if(buttons.ButtonState == 2)
            {
                return View("Success");
            }*/

            // re-display the buttons
            return View("Index", buttons);
        }

        public IActionResult ShowOneButton(int buttonNumber)
        {
            // add one to the button state. If greater than 4, reset to 0.
            buttons.ElementAt(buttonNumber).ButtonState = (buttons.ElementAt(buttonNumber).ButtonState + 1) % 4;

            //get the HTML string for one button. This function is define below.
            var buttonHTMLString = RenderRazorViewToString(this, "ShowOneButton", buttons.ElementAt(buttonNumber));

            //get the HTML string for a win or lose message
            bool didIWin = true;
            for (int i = 0; i < buttons.Count; i++)
                if (buttons.ElementAt(0).ButtonState != buttons.ElementAt(i).ButtonState)
                    didIWin = false;
            var messageHTMLString = "";
            if (didIWin)
                messageHTMLString = "<p>Congralutations. All buttons match the same color</p>";
            else
                messageHTMLString = "<p>Not all the buttons are the same color. See if you can make them match.</p>";

            //Combine the two strings into one JSON object and return the string
            return Json(new { part1 = buttonHTMLString, part2 = messageHTMLString });

            // re-display the button that was clicked
            //return PartialView(buttons.ElementAt(buttonNumber));
        }

        // Method to render a partial view and save the results in a string
        public static string RenderRazorViewToString(Controller controller, string viewName, object model = null)
        {
            controller.ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                IViewEngine viewEngine = controller.HttpContext.RequestServices.GetService(typeof(ICompositeViewEngine)) as ICompositeViewEngine;
                ViewEngineResult viewResult = viewEngine.FindView(controller.ControllerContext, viewName, false);

                ViewContext viewContext = new ViewContext(
                    controller.ControllerContext,
                    viewResult.View,
                    controller.ViewData,
                    controller.TempData,
                    sw,
                    new HtmlHelperOptions()
                );

                viewResult.View.RenderAsync(viewContext);
                return sw.GetStringBuilder().ToString();
            }
        }

    }
}
