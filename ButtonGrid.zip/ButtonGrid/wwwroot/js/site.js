﻿// Write your JavaScript code
$(function () {
    console.log("Page is ready");

    // Check to see if jQuery is working properly and add click listener to every button on grid
    // this works for all .game-button elements that were initially loaded
    // but will not be bound to any dynamically created buttons
    //$(".game-button").click(function (event) {

    // this works for any .game-button elements founds on the document,
    // even if they were dynamically created.
    // the click listener is attached to the document (i.e. the body of the page)
    $(document).on("click", ".game-button", function (event) {
        event.preventDefault();

        // Capture the button number in a variable
        var buttonNumber = $(this).val(); // this is the button that was clicked
        console.log("Button number " + buttonNumber + " was clicked");
        doButtonUpdate(buttonNumber);
    });
});

// Print a partial view of a button
function doButtonUpdate(buttonNumber) {
    $.ajax({
        datatype: "json",
        method: 'POST',
        url: '/button/showOneButton',
        data: {
            "buttonNumber": buttonNumber
        },
        // Partial page data received from the controller replaces a specific location on the web page.
        success: function (data) {
            console.log(data);
            // data should come in two parts: a button and a win/lose message
            $("#" + buttonNumber).html(data.part1);
            $("#messageArea").html(data.part2);
        }
    });
};